export const site = {
  name: "AbaNtu Intelligence",
  descriptor: "Digital systems for people, institutions and opportunity.",
  email: "thabelephangalele@outlook.com",
  phone: "+27 73 086 2149",
  location: "Johannesburg, South Africa",
};

export const services = [
  {
    title: "Websites & Digital Presence",
    text: "Fast, responsive institutional and business websites designed around real users, clear information and measurable outcomes.",
  },
  {
    title: "Web Applications",
    text: "Custom platforms for workflows, marketplaces, profiles, applications, records and organisation-specific processes.",
  },
  {
    title: "Digital Commerce",
    text: "Product catalogues, quotation workflows, commerce interfaces and structured product information for growing businesses.",
  },
  {
    title: "Education Technology",
    text: "Digital platforms and information systems that support schools, educators, parents, learners and education institutions.",
  },
  {
    title: "Civic & Public Systems",
    text: "Citizen-facing and internal systems designed to make public information and services easier to access and manage.",
  },
  {
    title: "Digital Transformation",
    text: "A practical path from fragmented manual processes to maintainable digital systems, with capacity building included.",
  },
];

export const sectors = [
  {
    title: "Government",
    text: "Citizen services, information systems, digital workflows and public-sector modernisation.",
  },
  {
    title: "Education",
    text: "Schools, education organisations, teachers, parents and learners need digital infrastructure built for their context.",
  },
  {
    title: "SMMEs",
    text: "Affordable digital commerce, websites, business systems and operational tools that can grow with the organisation.",
  },
  {
    title: "Community Organisations",
    text: "Digital tools for churches, nonprofits and community initiatives that need reliable information and engagement systems.",
  },
  {
    title: "Institutions",
    text: "Purpose-built platforms for organisations with specialised workflows, data and stakeholder requirements.",
  },
  {
    title: "Strategic Partners",
    text: "Technology, development and investment partners looking for practical African digital infrastructure opportunities.",
  },
];

export const projects = [
  {
    title: "UmsebenziWethu",
    slug: "umsebenziwethu",
    sector: "Employment Technology",
    tag: "Platform",
    summary: "A digital opportunity platform connecting employers, job seekers and employment information through a social-first experience.",
    challenge: "Opportunity information is fragmented and job seekers often need to navigate multiple disconnected channels.",
    solution: "A Django/DRF backend and React frontend supporting employer and job-seeker roles, job posts, applications, profiles and a social-style timeline.",
    technology: ["Python", "Django", "Django REST Framework", "React", "PostgreSQL", "Render"],
    strategic: "A foundation for a broader employment and opportunity ecosystem.",
  },
  {
    title: "Educore Digital Commerce",
    slug: "educore-digital-commerce",
    sector: "SMME Digitalisation",
    tag: "Commerce",
    summary: "A structured digital catalogue and quotation ecosystem for a stationery, hygiene and PPE supplier.",
    challenge: "A large physical product range needed consistent digital structure, searchable information and a scalable catalogue workflow.",
    solution: "Product data architecture, image processing, category mapping, catalogue interfaces, quote-basket workflows and deployment/SEO infrastructure.",
    technology: ["React", "Vite", "JavaScript", "CSV/Data Pipelines", "Google Sheets", "Axxess", "Render"],
    strategic: "Demonstrates how an SMME can turn a traditional product operation into structured digital commerce infrastructure.",
  },
  {
    title: "AbaNtu Education Ecosystem",
    slug: "abantu-education-ecosystem",
    sector: "Education Technology",
    tag: "Vision",
    summary: "A long-term digital public education ecosystem connecting schools, teachers, parents, learners and research.",
    challenge: "Many education institutions need more than isolated websites; they need connected digital infrastructure.",
    solution: "A planned ecosystem spanning an online public school, research institute, teacher academy, parent academy and AI-enabled learning services.",
    technology: ["Python", "Django", "Django Channels", "REST APIs", "PostgreSQL", "Redis", "Docker"],
    strategic: "A platform vision for scalable education infrastructure rather than a single-purpose website.",
  },
  {
    title: "Municipal Utility Intelligence",
    slug: "municipal-utility-intelligence",
    sector: "Civic Technology",
    tag: "Civic",
    summary: "A digital utility-account interface concept focused on statements, municipal accounts and clearer citizen-facing information.",
    challenge: "Utility information can be difficult to interpret when account, statement and service information is fragmented.",
    solution: "A web application architecture with authenticated API access, municipal accounts and statement workflows.",
    technology: ["Python", "Django", "Django REST Framework", "React", "PostgreSQL"],
    strategic: "Illustrates how citizen-facing digital systems can make complex public information more usable.",
  },
  {
    title: "TechChoice SA",
    slug: "techchoice-sa",
    sector: "Digital Commerce",
    tag: "Commerce",
    summary: "An electronics commerce platform architecture with structured catalogue specifications and scalable product data.",
    challenge: "Electronics catalogues require consistent technical specifications across very different product categories.",
    solution: "Category-specific specification modelling, product catalogue structure and an API-ready commerce backend.",
    technology: ["Python", "Django", "Django REST Framework", "PostgreSQL", "React"],
    strategic: "Demonstrates reusable product-data infrastructure for a complex commerce catalogue.",
  },
  {
    title: "Property Rental Platform",
    slug: "property-rental-platform",
    sector: "Property Technology",
    tag: "Platform",
    summary: "A property rental application designed around listings, users and digital property workflows.",
    challenge: "Property information and rental interactions benefit from structured data and purpose-built digital workflows.",
    solution: "A Django API and frontend application architecture for property listings and rental operations.",
    technology: ["Python", "Django", "Django REST Framework", "React", "PostgreSQL"],
    strategic: "A foundation for a broader property-management and rental marketplace product.",
  },
];

export const insights = [
  {
    title: "Beyond Websites: Building Digital Infrastructure for African Organisations",
    slug: "beyond-websites-digital-infrastructure",
    category: "Digital Transformation",
    excerpt: "A website is often only the visible layer. Sustainable transformation requires data, workflows, people and systems underneath it.",
  },
  {
    title: "What Should a Digital Public School Actually Be?",
    slug: "what-should-a-digital-public-school-be",
    category: "Education Technology",
    excerpt: "Digital education infrastructure should connect learners, teachers, parents, institutions and knowledge—not simply reproduce a classroom online.",
  },
  {
    title: "Why SMME Digitalisation Needs More Than a Brochure Website",
    slug: "smme-digitalisation-needs-more-than-a-website",
    category: "SMMEs",
    excerpt: "For a growing business, catalogue data, enquiries, quotations, operations and discoverability can matter as much as the homepage.",
  },
  {
    title: "Designing Technology for Real Infrastructure Constraints",
    slug: "technology-for-real-infrastructure-constraints",
    category: "African Technology",
    excerpt: "Good digital architecture accounts for bandwidth, device access, maintenance capacity, cost and the operational environment.",
  },
];

export const values = [
  ["Problem first", "We start with the operational problem, not with a fashionable technology."],
  ["Appropriate technology", "The best architecture is the one an organisation can actually afford, operate and sustain."],
  ["Human-centred systems", "Users, administrators and communities are part of the design process."],
  ["Build for growth", "We favour modular systems that can evolve instead of disposable prototypes."],
  ["Knowledge transfer", "Documentation, training and maintainability are part of responsible delivery."],
];