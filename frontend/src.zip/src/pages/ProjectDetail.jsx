import { useCallback } from "react";
import { Link, useParams } from "react-router-dom";
import { projects as localProjects } from "../data/site";
import useApiResource from "../hooks/useApiResource";
import { getProject } from "../services/projects";

export default function ProjectDetail() {
  const { slug } = useParams();
  const local = localProjects.find((item) => item.slug === slug);
  const loader = useCallback(() => getProject(slug), [slug]);
  const { data } = useApiResource(loader, null);
  const project = data || local;

  if (!project) {
    return <main className="page"><div className="container narrow center"><h1>Project not found.</h1><Link className="text-link" to="/projects">Back to our work →</Link></div></main>;
  }

  return (
    <main className="page">
      <div className="container narrow page-intro">
        <span className="eyebrow">{project.tag || "Case study"} · {project.sector}</span>
        <h1>{project.title}</h1>
        <p>{project.summary}</p>
      </div>
      <section className="section">
        <div className="container case-grid">
          <div className="case-main">
            <CaseBlock title="The challenge" text={project.challenge} />
            <CaseBlock title="Our approach" text={project.solution} />
            <CaseBlock title="Strategic significance" text={project.strategic} />
          </div>
          <aside className="case-aside">
            <h3>Technology</h3>
            <div className="tech-list">{(project.technology || []).map((tech) => <span key={tech}>{tech}</span>)}</div>
          </aside>
        </div>
      </section>
    </main>
  );
}

function CaseBlock({ title, text }) {
  return <div className="case-block"><span className="eyebrow">{title}</span><p>{text}</p></div>;
}